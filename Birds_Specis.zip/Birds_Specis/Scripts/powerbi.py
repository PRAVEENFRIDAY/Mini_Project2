# Import necessary libraries
import pandas as pd

# Step 1: Data Cleaning and Preprocessing
def load_and_clean_data(file_path):
    """
    Load and clean the dataset from multiple Excel sheets.
    """
    # Load all sheets from the Excel file
    sheets_dict = pd.read_excel(file_path, sheet_name=None)
    
    # Combine all sheets into a single dataframe
    combined_df = pd.concat(sheets_dict.values(), ignore_index=True)
    
    # Handle missing values
    combined_df.dropna(subset=['Scientific_Name', 'Location_Type'], inplace=True)
    
    # Standardize columns (e.g., ensure consistent formatting for Date and Time)
    combined_df['Date'] = pd.to_datetime(combined_df['Date'])
    combined_df['Start_Time'] = pd.to_datetime(combined_df['Start_Time'], format='%H:%M:%S').dt.time
    combined_df['End_Time'] = pd.to_datetime(combined_df['End_Time'], format='%H:%M:%S').dt.time
    
    # Filter relevant columns for analysis
    relevant_columns = [
        'Admin_Unit_Code', 'Site_Name', 'Plot_Name', 'Location_Type', 'Year', 'Date', 
        'Start_Time', 'End_Time', 'Scientific_Name', 'Common_Name', 'Sex', 
        'Temperature', 'Humidity', 'Sky', 'Wind', 'Disturbance', 'PIF_Watchlist_Status', 
        'Regional_Stewardship_Status'
    ]
    combined_df = combined_df[relevant_columns]
    
    return combined_df

# Step 2: Save the cleaned dataset as a CSV file
def save_cleaned_data(df, output_file):
    """
    Save the cleaned dataset as a CSV file for Power BI.
    """
    df.to_csv(output_file, index=False)

# Main Function
def main():
    # Step 1: Load and clean the data
    file_path = '"D:/GuviCoruseDoc/combined_bird_Species_data.xlsx"'  # Replace with your file path
    cleaned_df = load_and_clean_data(file_path)
    
    # Step 2: Save the cleaned dataset as a CSV file
    output_file = 'cleaned_bird_data.csv'
    save_cleaned_data(cleaned_df, output_file)
    print(f"Cleaned dataset saved as {output_file}")

# Run the program
if __name__ == "__main__":
    main()